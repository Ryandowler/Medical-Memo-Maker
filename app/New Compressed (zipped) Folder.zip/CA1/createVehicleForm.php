<!DOCTYPE html>
<!-- All the CSS and HTML Code -->
<html>
    <head>
	<link rel="stylesheet" type="text/css" href=Css/style.css>
	<!-- this is our style sheet for styling the site-->
        <meta charset="UTF-8">
        <link rel="shortcut icon" href="http://faviconist.com/icons/6f414caa507cee1b06793df28be99582/favicon.ico" />
        <title>Irish Tour Bus Company</title>
        <meta charset="UTF-8">
        <script type="text/javascript" src="js/createVehicleForm.js"></script>
    </head>
    <body> 
        <!-- Main Container -->
        <img src="images/mainLogo.png" alt="Main Logo">
        <div id="container">
            <!-- form with a action event on createVehicle.php with a submit to validate on the js form createVehicleForm.js -->
            <form action="createVehicle.php" 
              method="POST"
              onsubmit="return validateCreateVehicle(this);">
            <!-- The table that contains the input fields -->
            <table border="0">
                <tbody>
                    <tr>
                        <td>Registration Number</td>
                        <td>
                            <!-- Input boxs -->
                            <input type="text" name="registration1" value="<?php
                                    if (isset($_POST) && isset($_POST['registration1'])) {
                                        echo $_POST['registration1'];
                                    }
                                    ?>" />
                            <!-- If $errorMessage isset to registration1 then it prints out the message from createVehicle.php (Same for all the rest) -->
                             <span id="registration1Error" class="error">
                                <?php
                                if (isset($errorMessage) && isset($errorMessage['registration1'])) {
                                    echo $errorMessage['registration1'];
                                }
                                ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <td>Make</td>
                        <td>
                            <input type="text" name="make1" value="<?php
                                    if (isset($_POST) && isset($_POST['make1'])) {
                                        echo $_POST['make1'];
                                    }
                                    ?>" />
                            <span id="make1Error" class="error">
                                <?php
                                if (isset($errorMessage) && isset($errorMessage['make1'])) {
                                    echo $errorMessage['make1'];
                                }
                                ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <td>Model</td>
                        <td>
                            <input type="text" name="model1" value="<?php
                                    if (isset($_POST) && isset($_POST['model1'])) {
                                        echo $_POST['model1'];
                                    }
                                    ?>" />
                            <span id="model1Error" class="error">
                                <?php
                                if (isset($errorMessage) && isset($errorMessage['model1'])) {
                                    echo $errorMessage['model1'];
                                }
                                ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <td>Number Of Seats</td>
                        <td>
                            <input type="text" name="seats1" value="<?php
                                    if (isset($_POST) && isset($_POST['seats1'])) {
                                        echo $_POST['seats1'];
                                    }
                                    ?>" />
                            <span id="seats1Error" class="error">
                                <?php
                                if (isset($errorMessage) && isset($errorMessage['seats1'])) {
                                    echo $errorMessage['seats1'];
                                }
                                ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <td>Engine Size</td>
                        <td>
                            <input type="text" name="engine1" value="<?php
                                    if (isset($_POST) && isset($_POST['engine1'])) {
                                        echo $_POST['engine1'];
                                    }
                                    ?>" />
                              <span id="engine1Error" class="error">
                                <?php
                                if (isset($errorMessage) && isset($errorMessage['engine1'])) {
                                    echo $errorMessage['engine1'];
                                }
                                ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <td>Date Of Purchase</td>
                        <td>
                            <input type="text" name="purchase1" value="<?php
                                    if (isset($_POST) && isset($_POST['purchase1'])) {
                                        echo $_POST['purchase1'];
                                    }
                                    ?>" />
                            <span id="purchase1Error" class="error">
                                <?php
                                if (isset($errorMessage) && isset($errorMessage['purchase1'])) {
                                    echo $errorMessage['purchase1'];
                                }
                                ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <td>Next Service Date</td>
                        <td>
                            <input type="text" name="service1" value="<?php
                                    if (isset($_POST) && isset($_POST['service1'])) {
                                        echo $_POST['service1'];
                                    }
                                    ?>" />
                            <span id="service1Error" class="error">
                                <?php
                                if (isset($errorMessage) && isset($errorMessage['service1'])) {
                                    echo $errorMessage['service1'];
                                }
                                ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <!-- If submitted/ button pressed and no errorMessages were met or printed then home.php is loaded -->
                            <input type="submit" value="Register Bus" name="createVehicle" />
                             <input type="button" value="Return" name="forgot" onclick="document.location.href = 'home.php'" />
                        </td>
                    </tr>
                </tbody>
            </table>
        </form>
        </div>
    </body>
</html>
