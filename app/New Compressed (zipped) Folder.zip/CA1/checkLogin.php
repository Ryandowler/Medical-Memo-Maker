<?php
/* Reloads User.php file only once to the code*/
require_once 'User.php';

/* Starts a new session if session is == to nothing */
$id = session_id();
if ($id == "") {
    session_start();
}

/* Validate form data plus, filter content in input to prevent secruity, prevents php or other code to be entered */
$username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
$_SESSION['username'] = $username;
$password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

/* Error messege array to validate filled out form for the login system */
/*  If for example $username is blank or false then the $errorMessage is set below */
$errorMessage = array();
if ($username === FALSE || $username === '') {
    $errorMessage['username'] = '-Username must not be blank<br/>';
}

if ($password === FALSE || $password === '') {
    $errorMessage['password'] = '-Password must not be blank<br/>';
}

if ($username !== 'Joshua' && $password !== 'secret') {
    $errorMessage['password'] = '-Invalid username or password<br/>';
}

/* so if the $errorMessage is blank or returns false then the checkLogin passes the code and users to home.php e.g Login successful! */
if (empty($errorMessage)) {
    if (!isset($_SESSION['users'])) {
        $users = array();
    }
    else {
        $users = $_SESSION['users'];
    }

    $user = new User($username, $password);

    $users[] = $user;

    $_SESSION['users'] = $users;
    
    header("Location: home.php");
}

/* If the $username == joe and $password == secret then the home.php will load e.g Login with joe */ 
if($username == 'joe' && $password == 'secret') {
    require 'home.php';
}

/* If the $username !== joe and $password !== secret then the home.php will not load and index.php page will reload */ 
else {
    require 'index.php';
}
