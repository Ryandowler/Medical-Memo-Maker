<?php
/* Reloads Vehicle.php file only once to the code*/
require_once 'Vehicle.php';

/* Starts a new session if session is == to nothing */
$id = session_id();
if ($id == "") {
    session_start();
}

/* If vehicles session is loaded or set then below code will run in the php */
if (!isset($_SESSION['vehicles'])) {
    $vehicles = array();
    
    /* setting $vehicles to new vehicles with values in the brackets to fill the table below in the html code */
    $vehicles[] = new vehicle("2A-367983", "Ford", "902A", "75", "5.7L", "11-11-09", "28-06-13");
    $vehicles[] = new vehicle("8T-390783", "Mercedes", "Aero", "15", "1.5L", "09-1-04", "28-06-13");
    $vehicles[] = new vehicle("6F-547190", "Navistar", "Centro-CX", "32L", "2.3", "03-10-14", "28-06-13");
    $vehicles[] = new vehicle("1C-001338", "Hyundai", "ALx-500", "48", "3.0L", "28-06-13", "28-06-13");
    
    $_SESSION['vehicles'] = $vehicles;
}

/* else the $vehicles session is reset to $vehicles thus reloading all elements and the page */
else {
    $vehicles = $_SESSION['vehicles'];
}
?>

<!DOCTYPE html>
<!-- All the CSS and HTML Code -->
<html>
    <head>
        <!-- Loading ythe favicon for the html page -->
        <link rel="shortcut icon" href="http://faviconist.com/icons/6f414caa507cee1b06793df28be99582/favicon.ico" />
        <title>Irish Tour Bus Company</title>
        <meta charset="UTF-8">
    </head>
    <body>
        <?php 
        if (isset($message)) {
            echo '<p>'.$message.'</p>';
        }
        ?>
    <div id="table">
        <img src="images/mainLogo.png" alt="Main Logo"><br>
        <!--  Calls in the session $username the prints it out -->
         <?php
         $username = $_SESSION['username'];
        echo 'Hello, ' . $username;
        ?>
        <div id="container1">
            <h1> Register </h1>
            <!-- makes the html table -->
            <table border="1">
                <thead>
                    <tr>
                        <th>Registration Number</th>
                        <th>Make</th>
                        <th>Model</th>
                        <th>Number Of Seats</th>
                        <th>Engine Size</th>
                        <th>Purchase/ Date</th>
                        <th>Service/ Date</th>
                    </tr>
                </thead>
                <tbody>
                <!-- calling the attributes from the $vehicles array and printing them into the table set in the html code -->
                <?php
                foreach ($vehicles as $p) {
                    echo '<tr>';
                    echo '<td>' . $p->getRegistration() . '</td>';
                    echo '<td>' . $p->getMake() . '</td>';
                    echo '<td>' . $p->getModel() . '</td>';
                    echo '<td>' . $p->getSeats() . '</td>';
                    echo '<td>' . $p->getEngine() . '</td>';
                    echo '<td>' . $p->getPurchase() . '</td>';
                    echo '<td>' . $p->getService() . '</td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
            </table><br>
        <!-- Buttons to load the creatVehicleForm.php and the index.php pages -->
        <input type="button" value="Enter Bus" name="forgot" onclick="document.location.href = 'createVehicleForm.php'" />
        <input type="button" value="Logout" name="forgot" onclick="document.location.href = 'index.php'" />
        </div>
    </body>
</html>
