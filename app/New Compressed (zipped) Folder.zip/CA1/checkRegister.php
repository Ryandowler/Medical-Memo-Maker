<?php
/* Reloads User.php file only once to the code*/
require_once 'User.php';

/* Starts a new session if session is == to nothing */
$id = session_id();
if ($id == "") {
    session_start();
}

/* Validate form data plus, filter content in input to prevent secruity, prevents php or other code to be entered */
$username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
$password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
$password2 = filter_input(INPUT_POST, 'password2', FILTER_SANITIZE_STRING);
$_SESSION['username'] = $username;

/* empty ErrorMessage array that if elements are met or not runs, either runs the error messege( Reloads register.php ) or continues to home.php */
$errorMessage = array();
if ($username === FALSE || $username === '') {
    $errorMessage['username'] = '-Username must not be blank<br/>';
}
else if ($username === 'Joshua') {
    $errorMessage['username'] = '-Username already registered<br/>';
}

if ($password === FALSE || $password === '') {
    $errorMessage['password'] = '-Password must not be blank<br/>';
}

if ($password2 === FALSE || $password2 === '') {
    $errorMessage['password2'] = '-Confirm must not be blank<br/>';
}
else if ($password !== $password2) {
    $errorMessage['password2'] = '-Passwords must match<br/>';
}

/* Runs when the error messege is empty or when all requests are met */
if (empty($errorMessage)) {
    if (!isset($_SESSION['users'])) {
        $users = array();
    }
    else {
        $users = $_SESSION['users'];
    }

    $user = new User($username, $password);

    $users[] = $user;

    $_SESSION['users'] = $users;

     header("Location: home.php");
}
/* when the array if/ else statements are not met */
else {
    require 'register.php';
}



