<?php

/* Reloads Vehicle.php file only once to the code*/
require_once 'Vehicle.php';

/* Starts a new session if session is == to nothing */
$id = session_id();
if ($id == "") {
    session_start();
}

//$registration= $_POST['registration'];
//$make = $_POST['make'];
//$model = $_POST['model'];
//$seats = $_POST['seats'];
//$engine = $_POST['engine'];
//$purchase = $_POST['purchase'];
//$service = $_POST['service'];

/* Validate form data plus, filter content in input to prevent secruity, plus prevents php or other code entered */
$registration1 = filter_input(INPUT_POST, 'registration1', FILTER_SANITIZE_STRING);
$make1 = filter_input(INPUT_POST, 'make1', FILTER_SANITIZE_STRING);
$model1 = filter_input(INPUT_POST, 'model1', FILTER_SANITIZE_STRING);
$seats1 = filter_input(INPUT_POST, 'seats1', FILTER_SANITIZE_STRING);#
$engine1 = filter_input(INPUT_POST, 'engine1', FILTER_SANITIZE_STRING);
$purchase1 = filter_input(INPUT_POST, 'purchase1', FILTER_SANITIZE_STRING);
$service1 = filter_input(INPUT_POST, 'service1', FILTER_SANITIZE_STRING);

/* empty ErrorMessage array that if elements are met or not runs, either runs the error messege( Reloads creatsVehicleForm.php ) or continues to home.php */
$errorMessage = array();
if ($registration1 === FALSE || $registration1 === '') {
    $errorMessage['registration1'] = '-Registration must not be blank<br/>';
}

if ($make1 === FALSE || $make1 === '') {
    $errorMessage['make1'] = '-Make must not be blank<br/>';
}

if ($model1 === FALSE || $model1 === '') {
    $errorMessage['model1'] = '-Model must not be blank<br/>';
}

if ($seats1 === FALSE || $seats1 === '') {
    $errorMessage['seats1'] = '-Seats must not be blank<br/>';
}

if ($engine1 === FALSE || $engine1 === '') {
    $errorMessage['engine1'] = '-Engine size must not be blank<br/>';
}

if ($purchase1 === FALSE || $purchase1 === '' ) {
    $errorMessage['purchase1'] = '-Purchase date must not be blank<br/>';
}

if ($service1 === FALSE || $service1 === '') {
    $errorMessage['service1'] = '-Services date must not be blank<br/>';
}

/* Runs when the error messege is met, thus producing a die request */
if (!isset($_SESSION['vehicles'])) {
    die("Illegal Request");
} 
else {
    $vehicles = $_SESSION['vehicles'];
}

/* Runs when the error messege is empty or when all requests are met */
if (empty($errorMessage)) {
    
$vehicle = new Vehicle($registration1, $make1, $model1, $seats1, $engine1, $purchase1, $service1);

$vehicles[] = $vehicle;

$_SESSION['vehicles'] = $vehicles;

$message = "Bus Details Added Successfully";

 header("Location: home.php");

require 'home.php';
}

/* when the array if/ else statements are not met */
else {
    require 'createVehicleForm.php';
}



