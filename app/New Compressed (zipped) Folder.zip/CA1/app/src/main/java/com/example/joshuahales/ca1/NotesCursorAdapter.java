package com.example.joshuahales.ca1;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

public class NotesCursorAdapter extends CursorAdapter {
    public NotesCursorAdapter(Context context, Cursor c, int flags) {
        super(context, c, flags);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(
                R.layout.note_list_item, parent, false
        );
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {

        String noteName = cursor.getString(
                cursor.getColumnIndex(DBOpenHelper.NOTE_NAME));
        String phoneText = cursor.getString(
                cursor.getColumnIndex(DBOpenHelper.NOTE_CREATED));
        String noteText = cursor.getString(
                cursor.getColumnIndex(DBOpenHelper.NOTE_TEXT));

        int pos = noteName.indexOf(10);
        if (pos != -1) {
            noteName = noteName.substring(0, pos) + "...";
        }
        if (noteName.length() >= 20) {
            noteName = noteName.substring(0, 20) + "...";
        }
        if (phoneText.length() >= 10){
            phoneText = phoneText.substring(0, 10);
        }
        if (noteText.length() >= 20) {
            noteText = noteText.substring(0, 20) + "...";
        }

        TextView tv = (TextView) view.findViewById(R.id.tvNote);
        TextView tv2 = (TextView) view.findViewById(R.id.tvNote2);
        TextView tv3 = (TextView) view.findViewById(R.id.tvNote3);
        tv.setText(noteName);
        tv2.setText(phoneText);
        tv3.setText(noteText);
    }
}
