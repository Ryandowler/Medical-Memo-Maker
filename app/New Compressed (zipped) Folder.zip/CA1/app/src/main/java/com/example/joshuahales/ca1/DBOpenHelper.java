package com.example.joshuahales.ca1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBOpenHelper extends SQLiteOpenHelper {

    //Constants for db name and version
    private static final String DATABASE_NAME = "notes.db";
    private static final int DATABASE_VERSION = 9;

    //Constants for identifying table and columns
    public static final String TABLE_NOTES = "notes";
    public static final String NOTE_ID = "_id";
    public static final String NOTE_TEXT = "noteText";
    public static final String NOTE_NAME = "noteName";
    public static final String NOTE_PHONE = "notePhone";
    public static final String NOTE_DATE = "noteDate";
    public static final String NOTE_PRICE = "notePrice";
    public static final String NOTE_CHECK_BOX = "noteCheckBox";
    public static final String NOTE_CREATED = "noteCreated";
    public static final String NOTE_LAST_UPDATED = "noteLastUpdated";

    public static final String[] ALL_COLUMNS =
            {NOTE_ID, NOTE_TEXT, NOTE_NAME, NOTE_PHONE, NOTE_DATE, NOTE_PRICE, NOTE_CHECK_BOX, NOTE_CREATED, NOTE_LAST_UPDATED};

    //SQL to create table
    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_NOTES + " (" +
                    NOTE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    NOTE_TEXT + " TEXT, " +
                    NOTE_NAME + " TEXT, " +
                    NOTE_PHONE + " TEXT, " +
                    NOTE_DATE + " TEXT, " +
                    NOTE_PRICE + " REAL, " +
                    NOTE_CHECK_BOX + " INTEGER, " +
                    NOTE_CREATED + " TEXT default CURRENT_TIMESTAMP, " +
                    NOTE_LAST_UPDATED + " TEXT" +
                    ")";

    public DBOpenHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTES);
        onCreate(db);
    }
}
