package com.example.joshuahales.ca1;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class EditorActivity extends AppCompatActivity {

    private String action;
    private String noteFilter;

    private EditText editor;
    private String oldText;

    private EditText editorName;
    private String oldName;

    private EditText editorPhone;
    private String oldPhone;

    private EditText editorDate;
    private String oldDate;

    private EditText editorPrice;
    private String oldPrice;

    private TextView editorLastUpdated;
    private String oldLastUpdated;
    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    Date date = new Date();

    private CheckBox ch;
    int checked = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        editor = (EditText) findViewById(R.id.editText);
        editorName = (EditText) findViewById(R.id.editName);
        editorPhone = (EditText) findViewById(R.id.editPhoneNo);
        editorDate = (EditText) findViewById(R.id.editDate);
        editorPrice = (EditText) findViewById(R.id.editPrice);
        editorLastUpdated = (TextView) findViewById(R.id.editLastUpdated);

        Intent intent = getIntent();

        Uri uri = intent.getParcelableExtra(NotesProvider.CONTENT_ITEM_TYPE);

        if (uri == null) {
            action = Intent.ACTION_INSERT;
            setTitle(getString(R.string.new_note));
        } else {
            action = Intent.ACTION_EDIT;
            noteFilter = DBOpenHelper.NOTE_ID + "=" + uri.getLastPathSegment();

            Cursor cursor = getContentResolver().query(uri,
                    DBOpenHelper.ALL_COLUMNS, noteFilter, null, null);
            cursor.moveToFirst();
            oldText = cursor.getString(cursor.getColumnIndex(DBOpenHelper.NOTE_TEXT));
            editor.setText(oldText);
            editor.requestFocus();

            oldPhone = cursor.getString(cursor.getColumnIndex(DBOpenHelper.NOTE_PHONE));
            editorPhone.setText(oldPhone);

            oldName = cursor.getString(cursor.getColumnIndex(DBOpenHelper.NOTE_NAME));
            editorName.setText(oldName);

            oldDate = cursor.getString(cursor.getColumnIndex(DBOpenHelper.NOTE_DATE));
            editorDate.setText(oldDate);

            oldPrice = cursor.getString(cursor.getColumnIndex(DBOpenHelper.NOTE_PRICE));
            editorPrice.setText(oldPrice);

            oldLastUpdated = cursor.getString(cursor.getColumnIndex(DBOpenHelper.NOTE_LAST_UPDATED));
            editorLastUpdated.setText(oldLastUpdated);
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (action.equals(Intent.ACTION_EDIT)) {
            getMenuInflater().inflate(R.menu.menu_editor, menu);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            case android.R.id.home:
                finishEditing();
                break;
            case R.id.action_delete:
                deleteNote();
                setResult(RESULT_OK);
                finish();
                break;
        }

        return true;
    }

    private void deleteNote() {
        getContentResolver().delete(NotesProvider.CONTENT_URI,
                noteFilter, null);
        Toast.makeText(this, getString(R.string.note_deleted),
                Toast.LENGTH_SHORT).show();
    }

    private void finishEditing() {
        String newText = editor.getText().toString().trim();
        String newName = editorName.getText().toString().trim();
        String phoneNo = editorPhone.getText().toString().trim();
        String newDate = editorDate.getText().toString().trim();
        String newPrice = editorPrice.getText().toString().trim();
        String newLastupdated = dateFormat.format(date);
        int phoneNum = 0;

        boolean finished = true;
        boolean validPhoneNumber = true;
        try {
            phoneNum = Integer.parseInt(phoneNo);
        } catch (NumberFormatException e) {
            validPhoneNumber = false;
        }

        boolean validDate = true;
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        try {
            df.parse(newDate);
        } catch (ParseException e) {
            validDate = false;
        }

        switch (action) {
            case Intent.ACTION_INSERT:
                if (newText.length() == 0 && phoneNo.length() == 0 && newName.length() == 0 && newDate.length() == 0 && newPrice.length() == 0) {
                    setResult(RESULT_CANCELED);
                }
                else if(phoneNo.length() > 0 && !validPhoneNumber) {
                    //Toast.makeText(this, "Phone number must be a integer", Toast.LENGTH_SHORT).show();
                    editorPhone.setError(Html.fromHtml("<font color='red'>Must be a number</font>"));
                    finished = false;
                }
                else if (newDate.length() > 0 && !validDate) {
                    //Toast.makeText(this, "Phone number must be a integer", Toast.LENGTH_SHORT).show();
                    editorDate.setError(Html.fromHtml("<font color='red'>Incorrect Date (dd-mm-yyyy)</font>"));
                    finished = false;
                }
                else {
                    insertNote(newText, phoneNum, newName, newDate, newPrice, newLastupdated);
                    setResult(RESULT_OK);
                }
                break;
            case Intent.ACTION_EDIT:
                if (newText.length() == 0 && phoneNo.length() == 0 && newName.length() == 0 && newDate.length() == 0 && newPrice.length() == 0) {
                    deleteNote();
                    setResult(RESULT_OK);
                }
                else if (oldText.equals(newText) && oldPhone.equals(phoneNo)&& oldName.equals(newName) && oldDate.equals(newDate) && oldPrice.equals(newPrice)) {
                    setResult(RESULT_CANCELED);
                }
                else if (phoneNo.length() > 0 && !validPhoneNumber) {
                    //Toast.makeText(this, "Phone number must be a integer", Toast.LENGTH_SHORT).show();
                    editorPhone.setError(Html.fromHtml("<font color='red'>Must be a number</font>"));
                    finished = false;
                }
                else if (newDate.length() > 0 && !validDate) {
                    //Toast.makeText(this, "Phone number must be a integer", Toast.LENGTH_SHORT).show();
                    editorDate.setError(Html.fromHtml("<font color='red'>Incorrect Date (dd-mm-yyyy)</font>"));
                    finished = false;
                }
                else {
                    updateNote(newText, phoneNum, newName, newDate, newPrice, newLastupdated);
                    setResult(RESULT_OK);
                }
        }
        if (finished) finish();
    }

    private void updateNote(String noteText, int phoneNum, String newName, String newDate, String newPrice, String newLastupdated) {
        ContentValues values = new ContentValues();
        values.put(DBOpenHelper.NOTE_TEXT, noteText);
        values.put(DBOpenHelper.NOTE_PHONE, phoneNum);
        values.put(DBOpenHelper.NOTE_NAME, newName);
        values.put(DBOpenHelper.NOTE_DATE, newDate);
        values.put(DBOpenHelper.NOTE_PRICE, newPrice);
        values.put(DBOpenHelper.NOTE_LAST_UPDATED, newLastupdated);
        getContentResolver().update(NotesProvider.CONTENT_URI, values, noteFilter, null);
        Toast.makeText(this, getString(R.string.note_updated), Toast.LENGTH_SHORT).show();
        setResult(RESULT_OK);
    }

    private void insertNote(String noteText, int phoneNum, String newName, String newDate, String newPrice, String newLastupdated) {
        ContentValues values = new ContentValues();
        values.put(DBOpenHelper.NOTE_TEXT, noteText);
        values.put(DBOpenHelper.NOTE_PHONE, phoneNum);
        values.put(DBOpenHelper.NOTE_NAME, newName);
        values.put(DBOpenHelper.NOTE_DATE, newDate);
        values.put(DBOpenHelper.NOTE_PRICE, newPrice);
        values.put(DBOpenHelper.NOTE_LAST_UPDATED, newLastupdated);
        getContentResolver().insert(NotesProvider.CONTENT_URI, values);
        setResult(RESULT_OK);
    }

    @Override
    public void onBackPressed() {
        finishEditing();
    }
}
